package com.way2learnonline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigtestApplication.class, args);
	}
}
